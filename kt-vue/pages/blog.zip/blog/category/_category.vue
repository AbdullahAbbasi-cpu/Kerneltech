
<template>
    <section class="py-[80px]">
      <div class="first-container-var">
          <div class="row flex justify-start lg:px-0 px-4 md:flex-row flex-col-reverse md:gap-[57px] gap-[30px]">
            <div class="md:w-[75%]">
                <h3 class="xl:text-f-45 md:text-f-30 text-f-26 font-fw-700 leading-lh-54 letest-news-h3 text-second-color-var">
                  Latest News
                </h3>
  
                <!-- main blog HTML starts from here -->
                <div id="default-tab-content">
                  <article v-for="post of posts" :key="post.slug" class="sm:p-4" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <div class="bg-first-color-var shadow-second-boxshadow-var mt-6">
                      <nuxt-link :to="`/blog/${post.slug}`">
                          <img :src="getImageSource(post.img)" class="min-h-[448px] max-h-[448px] blog-featured-image" alt="">
                          <div class="sm:px-[30px] px-[16px] pt-[17px]">
                            <div class="flex items-center mt-[12px] sm:gap-12 gap-8">
                                <div class="flex items-center gap-2">
                                  <img src="~/assets/images/profile-icon.svg" alt="">
                                  <p class="sm:text-f-18 text-f-14 font-fw-500 leading-lh-21 text-[#adadad] mb-0">
                                    {{ post.author.name }}
                                  </p>
                                </div>
                                <div class="flex items-center gap-2">
                                  <img src="~/assets/images/calendar.svg" alt="">
                                  <p class="sm:text-f-18 text-f-14 font-fw-500 leading-lh-21 text-[#adadad] mb-0">{{ post.published_date }}</p>
                                </div>
                            </div>
                            <h4 class="sm:text-f-24 text-f-20 font-fw-700 leading-lh-28 pt-4 text-second-color-var">
                              <nuxt-link :to="`/blog/${post.slug}`">
                                {{ post.title }}
                              </nuxt-link>
                            </h4>
                          </div>
                      </nuxt-link>
                      <div class="sm:px-[30px] px-[16px] pb-[30px]">
                          <p class="max-w-[661px] sm:text-f-18 text-f-14 font-fw-400 sm:leading-lh-30 leading-lh-26 mt-[5px]">
                            {{ post.description }}
                          </p>
                          <nuxt-link :to="`/blog/${post.slug}`">
                            <button class="blog-read-more text-f-16 bg-second-bg-color-var text-first-color-var py-[13px] px-[25px] rounded-second-radius-var mt-6 mb-2 hover:bg-transparent hover:border-[#0094F4] hover:text-third-color-var border-0 font-fw-500 leading-lh-19 transition-all duration-300">
                              Read More
                            </button>
                          </nuxt-link>
                      </div>
                    </div>
                  </article>
                  <!-- main blog HTML ends here -->
                </div>
            </div>
          </div>
      </div>
    </section>
  </template>
  <script>
    export default {
      layout:'MainFrontLayout',
      data() {
        return {
          posts: [],
        };
      },  
      methods: {
        getImageSource(imageName) {
          return require(`~/assets/images/${imageName}.png`);
        },
      },
      async fetch() {
        this.posts = await this.$content("articles").fetch();
        const category = this.$route.params.category;
        const filteredPosts = [];
        this.posts.forEach(post => {
            const formattedCategory = post.categories;
            JSON.stringify(formattedCategory);
            let firstCategory = formattedCategory[0];
            let holder = firstCategory.toLowerCase().replace(/\s+/g, '-');
            if(holder === category) {
                filteredPosts.push(post);
            }
        });
        this.posts = filteredPosts;
        console.log(this.posts);
      },
      computed: {
        filteredPosts() {
          const category = this.$route.params.category;
          return this.posts.filter(post => post.categories.includes(category));
        },
      },
      async asyncData({ params, $content }) {
        const page = parseInt(params.page) || 1;
        const limit = 5;
        const { pages } = await $content("articles").only(['slug']).fetch();
  
        return {
          page,
          pages: Math.ceil(pages / limit),
        };
      },
      async asyncData({ store }) {
        const headerData = {
          title: 'Blog',
          description: 'We started our journey in 2012. And looking back it has been an awesome ride with lots of ups and downs. But whatever be the situation, we were always trying to move forward.',
          description1: 'Icing croissant croissant jelly gummi bears cotton candy jujubes apple pie caramels. Dragée soufflé bonbon powder. Sesame snaps sugar plum chupa chups tart wafer caramels toffee.',
          bgImage: 'blog-banner-image',
          customClass: 'is-blogpage ',
        };
        await store.dispatch('setHeaderData', headerData);
        return {
        };
      },
      head() {
        return {
          title: 'Blog | Kerneltech',
        };
      },
      name: 'Blog',
    };
  </script>